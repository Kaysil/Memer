# Memer PLUGIN #
### Memer plugin for C3CBot
### Author: Kaysil (me) ##

### Usage/Using:
- Put it to ./plugins folder then run your bot
#### Command:
- Main command: /pls
  - Subcommand: sounds

#### Example:
- none

#### like Dank Memer in Discord (thonk)
